import math

def calculate_math_functions():
            num_str = input("Enter a number: ")
            number = float(num_str)
            square_root = math.sqrt(number)
            print("Square Root:", square_root)
            natural_logarithm = math.log(number)
            print("Logarithm: ", natural_logarithm)
            sine_value = math.sin(number)
            print("Sine : ", sine_value)

calculate_math_functions()




