a=input('enter the first number: ')
b=input('enter the second number: ')
a=int(a)
b=int(b)

add=a+b
sub=a-b
mul=a*b
div=a/b

print(' Addition =',add)
print(' Subtraction =',sub)
print(' Multiplication =',mul)
print(' Division =',div)