from pytube import Playlist, YouTube
import os
import re


def sanitize_filename(name):
    """
    Sanitizes a string to be suitable for use as a filename or directory name.
    Removes invalid characters and replaces spaces with underscores.
    """
    return re.sub(r'[\\/:*?"<>|]', '', name).replace(' ', '_')


def download_video(video_url, resolution, output_base_path="."):
    """
    Downloads a single YouTube video to a specified resolution.
    """
    try:
        yt = YouTube(video_url)
        print(f"Video Title: {yt.title}")

        # Sanitize video title for folder and filename
        video_title_sanitized = sanitize_filename(yt.title)

        # Determine output path: subfolder named after video
        output_path = os.path.join(output_base_path, video_title_sanitized)

        if not os.path.exists(output_path):
            os.makedirs(output_path)
            print(f"Created download directory: '{output_path}'")
        else:
            print(f"Download directory already exists: '{output_path}'")

        stream = yt.streams.filter(res=resolution, file_extension='mp4').first()

        if not stream:
            print(f"Resolution '{resolution}' not available for '{yt.title}'.")
            print("Attempting to download the highest available resolution.")
            stream = yt.streams.get_highest_resolution()

        if stream:
            print(
                f"Downloading stream: Resolution={stream.resolution}, FPS={stream.fps}, File Size={stream.filesize / (1024 * 1024):.2f} MB")
            stream.download(output_path=output_path)
            print(f"Successfully downloaded: '{yt.title}'")
            return True  # Indicate success
        else:
            print(f"No suitable stream found for '{yt.title}' (URL: {video_url}). Skipping this video.")
            return False  # Indicate failure
    except Exception as e:
        print(f"Error downloading video '{video_url}' ({yt.title if 'yt' in locals() else 'Unknown Title'}): {e}")
        return False  # Indicate failure


def download_youtube_content(url, resolution="1080p"):
    """
    Attempts to download content as a YouTube playlist.
    If it fails, it attempts to download it as a single YouTube video.
    """
    is_playlist_downloaded = False
    try:
        # Attempt to treat as a playlist first
        playlist = Playlist(url)
        print(f"\n--- Downloading Playlist: {playlist.title} ---")

        # Create a directory for the playlist using a sanitized title
        playlist_dir = sanitize_filename(playlist.title)
        if not os.path.exists(playlist_dir):
            os.makedirs(playlist_dir)
            print(f"Created download directory: '{playlist_dir}'")
        else:
            print(f"Download directory already exists: '{playlist_dir}'")

        # Iterate through each video in the playlist
        for i, video_url in enumerate(playlist.video_urls):
            print(f"\n--- Processing Video {i + 1} of {len(playlist.video_urls)} ---")
            download_video(video_url, resolution, playlist_dir)  # Use the new download_video function

        print("\n--- Playlist download process complete! ---")
        is_playlist_downloaded = True

    except Exception as e:
        # If playlist download fails, try as a single video
        print(f"\nURL does not appear to be a playlist (Reason: {e}).")
        print("Attempting to download as a single video instead...")

        single_video_success = download_video(url, resolution,
                                              "YouTube_Downloads")  # Download single videos to a general folder

        if not single_video_success:
            print("\nFailed to download as a single video.")
            print("The provided URL is neither a valid YouTube playlist nor a valid YouTube video URL.")
            print("Please check the URL and your internet connection.")
        else:
            print("\n--- Single video download complete! ---")


if __name__ == "__main__":
    print("Welcome to YouTube Downloader!")
    print("This script can download both single YouTube videos and entire playlists.")
    url_input = input("Enter the YouTube Video or Playlist URL: ").strip()

    common_resolutions = ["144p", "240p", "360p", "480p", "720p", "1080p", "1440p", "2160p"]

    while True:
        resolution_input = input(
            f"Please select a desired video resolution from {common_resolutions} "
            f"or press Enter for default (1080p): ").strip().lower()

        if not resolution_input:
            selected_resolution = "1080p"
            print(f"Defaulting to resolution: {selected_resolution}")
            break
        elif resolution_input in common_resolutions:
            selected_resolution = resolution_input
            print(f"Selected resolution: {selected_resolution}")
            break
        else:
            print("Invalid resolution entered. Please choose from the provided list or press Enter.")

    # Call the main download function
    download_youtube_content(url_input, selected_resolution)