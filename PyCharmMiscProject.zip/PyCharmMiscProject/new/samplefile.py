# dict ={"Key1":2,"key2":1}
# dict2={"a":1,"b":2}
# print(dict)
#
# dict["key3"] = 3
# print(dict)
# del dict["key2"]
# del(dict2["b"])
# print(dict2)
# print(dict)
#
# print("key3" in dict)
#
# print(dict.keys())
# print(dict2.keys())
#
# print(dict.values())
# print(dict2.values())
#
# print(dict.get("key3"))
# print(dict2.get("a"))
# print(dict2.get("c"))
"""
file = open('my_file.txt','r')
read=file.read()
read1=file.readline()
print(read1)
print(read)
file.close()
#
"""


file = open('my_file.txt','w')
r=file.write('hello')
print(r)
file.close()

file1=open('my_file.txt','r')
q=file1.read()
print(q)
file1.close()


#append
file = open('my_file.txt','a')
r=file.write('\nhello')
print(r)
file.close()

file1=open('my_file.txt','r')
q=file1.read()
print(q)
file1.close()

