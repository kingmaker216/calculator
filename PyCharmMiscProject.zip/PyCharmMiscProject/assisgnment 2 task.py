import string

a=input('enter your first name: ')
b=input('enter your last name: ')
a=str(a)
b=str(b)
c= a+ ' '+ b
print("hello, ",c,"! welcome to the python program")