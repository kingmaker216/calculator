
total_sum = 0


for count in range(1, 51):
  total_sum += count


print("The sum of integers from 1 to 50 is:",total_sum )