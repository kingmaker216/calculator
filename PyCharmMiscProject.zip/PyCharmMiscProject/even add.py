a=int(input('enter the number: '))




if a%2==0 :
    print(a,'is a Even Number.')
else:
    print(a,'is a odd Number.')